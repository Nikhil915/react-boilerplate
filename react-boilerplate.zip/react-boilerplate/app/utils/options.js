export const mapToObject = n => ({ value: n, label: n });
