/*
 *
 * HomePage constants
 *
 */

export const DEFAULT_ACTION = 'app/HomePage/DEFAULT_ACTION';
