// import { fromJS } from 'immutable';
// import { selectHomePageDomain } from '../selectors';

describe('selectHomePageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
