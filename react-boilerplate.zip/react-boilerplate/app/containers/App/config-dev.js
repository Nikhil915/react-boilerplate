const config = {
  endpointHost: 'https://google.com',
};

export default config;
